-- The purpose of this file is to create and populate a database for Limbo
-- Fred Berberich and Aaron Bonilla
-- SQL

CREATE DATABASE IF NOT EXISTS limbo_db;

USE limbo_db;

DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS theStuff;
DROP TABLE IF EXISTS locations;

CREATE USER IF NOT EXISTS 'Bone'@'localhost'
IDENTIFIED WITH mysql_native_password BY 'Hungrybox';
GRANT SELECT, INSERT, UPDATE, DELETE ON limbo_db.* TO 'Bone'@'localhost';

-- Create a table called users
CREATE TABLE IF NOT EXISTS users(
theUser_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
first_name VARCHAR(20) NOT NULL,
last_name VARCHAR(40) NOT NULL,
email VARCHAR(60) NOT NULL,
pass VARCHAR(256) NOT NULL,
reg_date DATETIME NOT NULL,
UNIQUE(email));

-- Inserts values into users
INSERT INTO users(first_name, last_name, email, pass, reg_date)
VALUES
("admin","admin","admin@marist.edu",SHA2('gaze11e',256),NOW());

-- Create a table called locations
CREATE TABLE IF NOT EXISTS locations(
id INT AUTO_INCREMENT PRIMARY KEY,
create_date DATETIME NOT NULL,
update_date DATETIME NOT NULL,
name TEXT NOT NULL 
);

-- Insert values into locations
INSERT INTO locations(create_date, update_date, name)
VALUES
(NOW(),NOW(), "Hancock"),
(NOW(),NOW(), "Dyson"),
(NOW(),NOW(), "McCann Center"),
(NOW(),NOW(), "Lowell Thomas"),
(NOW(),NOW(), "Fontaine Hall"),
(NOW(),NOW(), "Allied Health"),
(NOW(),NOW(), "Steel Plant"),
(NOW(),NOW(), "Murray Student Center");

-- Create a table called theStuff
CREATE TABLE IF NOT EXISTS theStuff(
stuff_id INT AUTO_INCREMENT PRIMARY KEY,
location_id INT NOT NULL,
name TEXT NOT NULL,
theDescription TEXT NOT NULL, 
create_date DATETIME NOT NULL,
update_date DATETIME NOT NULL,
room TEXT,
theOwner TEXT,
finder TEXT,
theStatus SET ("found", "lost", "claimed") NOT NULL,
FOREIGN KEY(location_id)
  REFERENCES locations(id)
);

-- Inserts values of lost items into theStuff
INSERT INTO theStuff(location_id, name, theDescription, create_date, update_date, theOwner, theStatus)
VALUES
(8, "iphone", "Red iphone SE2 with a dog on the lockscreen", '2022-11-06 16:55:31', '2022-03-24 16:55:31', "Michael Varsames", "lost"),
(4, "water bottle", "Blue water bottle with a frog sticker on it", '2022-10-25 12:03:49', '2021-12-02 12:03:49', "Cristian Javier", "lost"),
(1, "textbook", "Green textbook on PHP and mySQL", '2022-11-10 18:30:00', '2022-08-30 18:30:00', "Mason Compton", "lost");

-- Inserts values of found items into theStuff
INSERT INTO theStuff(location_id, name, theDescription, create_date, update_date, room, finder, theStatus)
VALUES
(2, "airpods", "Airpods in a black case", '2022-11-12 9:41:22', '2022-11-12 9:41:22', "DY 215", "Gustav Tompuri", "found"),
(3, "car keys", "Subaru car keys with a Marist Lanyard", '2022-10-25 13:01:56', '2022-10-25 13:01:56', "River rooms", "Graham Ludwig", "found"),
(1, "mechanical pencil", "Pink mechanical pencil", '2022-11-13 7:54:51', '2022-11-13 7:54:51', "HC 2019", "Gabriel Vazquez", "found");

explain users; 
explain theStuff; 
explain locations;

SELECT * FROM users;
SELECT * FROM theStuff;
SELECT * FROM locations;
