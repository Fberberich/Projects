<!DOCTYPE html>
<html>
<!-- Allows the user to see and user hyperlinks -->
<h1>Quick Links</h1> 
</font>
<font size = "3"> 
<a href=lostSomething.php>Lost Something</a> <a href=foundSomething.php> Found Something </a> <a href=admin.php>Admin</a> 
<a href=stuff.php>Stuff</a> <a href=limbo.php>Limbo home</a> <a href=updateLost.php>Update lost item</a>
<a href=updateFound.php>Update found item</a>
<tr>
<table>
<tr> 
<tr>
</tr>
</table>

<?php

require( '../connect_limbo_db.php' ) ;
require ( 'includes/helpersLimbo.php');

if (isset($_POST['id'])){
    $id = $_POST['id'];
} else {
    $id = "";
}
if (isset($_POST['location'])){
    $location = $_POST['location'];
} else {
    $location = "";
}
if (isset($_POST['newN'])){
    $newN = $_POST['newN'];
} else {
    $newN = "";
}
if (isset($_POST['newD'])){
    $newD = $_POST['newD'];
} else {
    $newD = "";
}
if (isset($_POST['newR'])){
    $newR = $_POST['newR'];
} else {
    $newR = "";
}
if (isset($_POST['newF'])){
    $newF = $_POST['newF'];
} else {
    $newF = "";
}

if (($_SERVER['REQUEST_METHOD']=='POST')){ //variables are saved as blanks and used to populate form, this ensures errors are not shown before the user inputs values
    
    //error checking for if variables are blank
        if ($newN=='') {
            $error_message = "<br>Please enter a name";
            echo $error_message;
        } 
        if ($newD=='') {
            $error_message = "<br>Please enter a description";
            echo $error_message;
        } 
        if ($newR=='') {
            $error_message = "<br>Please enter a room";
            echo $error_message;
        } 
        if ($newF=='') {
            $error_message = "<br>Please enter a finder";
            echo $error_message;
        } 
}

show_records_changeable_found($dbc);

$query = "SELECT stuff_id FROM theStuff WHERE theStatus = 'found'";
$results = mysqli_query( $dbc , $query ) ;

//begin form
echo "<form action='' method='POST'>";
?>

<div>
    <label>ID:</label><select name='id' id='$id'>
    <?php
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) ){
        echo "<option value='" . $row['stuff_id'] . "'>" .$row['stuff_id']."</option>";
    }  
    ?>
    </select>  
</div>
<div>
        <label>Location:</label><select name='location' id='$location'>
        <option value='Hancock'>Hancock</option>
        <option value='Dyson'>Dyson</option>
        <option value='McCann Center'>McCann Center</option>
        <option value='Lowell Thomas'>Lowell Thomas</option>
        <option value='Fontaine Hall'>Fontaine Hall</option>
        <option value='Allied Health'>Allied Health</option>
        <option value='Steel Plant'>Steel Plant</option>
        <option value='Murray Student Center'>Murray Student Center</option>
        </select>
</div>

<div>
<label>New name:</label><input name='newN' id='$newN'>
<label>New description:</label><input name='newD' id='$newD'>
<label>New room:</label><input name='newR' id='$newR'>
<label>New finder:</label><input name='newF' id='$newF'>
    <label><input type='submit' class='btn' value='Submit'>
</div>

<?php

//end form
echo "</form>";


if ($_SERVER['REQUEST_METHOD']=='POST' and !isset($error_message)){
    if(update_record_found($dbc,$id,$location,$newN,$newD,$newR,$newF)){
        echo "<h1>Entry successfully updated, refresh to see changes</h1>";
    }
}