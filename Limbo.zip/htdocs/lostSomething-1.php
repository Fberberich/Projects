<?php
$year = $_POST[‘year’] ;
$location = $_POST[‘location’] ;
$description = $_POST[‘description’] ;


?>