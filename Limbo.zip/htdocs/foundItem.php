<!DOCTYPE html>
<html>
<!-- Allows the user to see and user hyperlinks -->
<h1>Quick Links</h1> 
</font>
<font size = "3"> 
<a href=lostSomething.php>Lost Something</a> <a href=foundSomething.php> Found Something </a> <a href=admin.php>Admin</a> 
<a href=stuff.php>Stuff</a> <a href=limbo.php>Limbo home</a> <a href=updateLost.php>Update lost item</a>
<a href=updateFound.php>Update found item</a>
<form action="stuff.php" method="POST">
<tr>
<table>
<tr> 
<tr>
</tr>
</table>
<?php
# Connect to MySQL server and the database
require( '../connect_limbo_db.php' ) ;

// Initialize stuff info on a GET
if ( $_SERVER[ 'REQUEST_METHOD' ] == 'GET' ) {
  $name = "" ;
  $description = "" ;
  $status = "" ;
}

# Includes these helper functions
require( 'includes/helpersLimbo.php' ) ;

if ($_SERVER[ 'REQUEST_METHOD' ] == 'GET') {
    if(isset($_GET['id']))
        show_record_lost($dbc, $_GET['id']) ;
}

?>

</font>
<font size = "3">
<a href=foundSomething.php>Go back</a>
<tr>
<table>
<tr> 
<tr>
</tr>
</table>