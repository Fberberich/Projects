<!DOCTYPE html>
<html>
<style>
    label{
        float: left;
        clear: left;
        width: 100px;
        text-align: left;
    }
    input{
        float: left;
    }
    .container .btn{
        float: left;
        clear: left;
        width: 100px;
        text-align: left;
    }
    
</style>        
<!-- Allows the user to see and use hyperlinks -->
<h1>Log out and go back to user view</h1> 
</font>
<font size = "3"> 
<a href=limbo.php>Limbo home</a>
<h1>Admin options</h1>
</font>
<font size = "3">
<a href=admin-2.php>Add found item</a> <a href=admin-3.php>Add lost item</a>
<a href=admin-4.php>Delete item</a> <a href=admin-5.php>Change status</a>
<a href=admin-6.php>Table of Admins</a>
<a href=admin-7.php>Add Admin</a>
<a href=admin-8.php>Delete Admin</a> 
<a href=admin-9.php>Change Password</a>
<a href=admin-10.php>Update Admin</a>
<tr>
<table>
<tr> 
<tr>
</tr>
</table>

<?php

require( '../connect_limbo_db.php' ) ;
require ( 'includes/helpersLimbo.php');

if (isset($_POST['id'])){
    $id = $_POST['id'];
} else {
    $location = "";
}
if (isset($_POST['newStatus'])){
    $newStatus = $_POST['newStatus'];
} else {
    $name = "";
}

show_records_changeable($dbc);

$query = "SELECT stuff_id FROM theStuff";
$results = mysqli_query( $dbc , $query ) ;

//begin form
echo "<form action='' method='POST'>";
?>

<div>
    <label>ID:</label><select name='id' id='$id'>
    <?php
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) ){
        echo "<option value='" . $row['stuff_id'] . "'>" .$row['stuff_id']."</option>";
    }  
    ?>
    </select>  
</div>

<div>
    <label>New Status:</label><select name='newStatus' id='$newStatus'>
      <option value='claimed'>claimed</option>
      <option value='lost'>lost</option>
      <option value='found'>found</option>
      </select>
      <label><input type='submit' class='btn' value='Submit'>
</div>

<?php

//end form
echo "</form>";


if ($_SERVER['REQUEST_METHOD']=='POST'){
    if(change_item($dbc,$id,$newStatus)){
        echo "<h1>Item successfully changed, refresh to see changes</h1>";
    }
}
