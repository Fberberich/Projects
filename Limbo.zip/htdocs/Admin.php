<!DOCTYPE html>
<html>
<style>
    label{
        float: left;
        clear: left;
        width: 100px;
        text-align: left;
    }
    input{
        float: left;
    }
    .container .btn{
        float: left;
        clear: left;
        width: 100px;
        text-align: left;
    }
    
</style>
<!-- Allows the user to see and use hyperlinks -->
</font>
<font size = "3"> 
<a href=limbo.php>Limbo home</a>
</font>
<font size = "3">
<tr>
<table>
<tr> 
<tr>
</tr>
</table>

<?php # DISPLAY COMPLETE LOGIN PAGE.

# Set page title and display header section.
#$page_title = 'Login' ;


 session_start();
    //connect to connect_limbo_db
    require( '../connect_limbo_db.php' ) ;
    echo "<h1> Login </h1>";

    //initialize variables to the user input or if the user input is missing, a blank
    if (isset($_POST['email'])){
        $email = $_POST['email'];
    } else {
        $email = "";
    }
    if (isset($_POST['pass'])){
        $pass = $_POST['pass'];
    } else {
        $pass = "";
    }


    if (($_SERVER['REQUEST_METHOD']=='POST')){ //variables are saved as blanks and used to populate form, this ensures errors are not shown before the user inputs values
    
    //error checking for if variables are blank
        if ($email==''){
            $error_message = "<br>Please enter a username";
            echo $error_message;
        } 
         if ($pass=='') {
             $error_message = "<br>Please enter a password";
             echo $error_message;
        } 
    }
   
    if (($_SERVER['REQUEST_METHOD']=='GET') OR (isset($error_message))){ //shows form only on first load or if user input has an error
        //begin form
        echo "<form action='' method='POST'>";

        ?>
        <div>
            <label>Email:</label><input value = '' type='text' name='email'>
            <label>Password:</label><input value = '' type='password' name='pass'>
            <label><input type='submit' class='btn' value='Login'>
        </div>
        <?PHP

        //end form
        echo "</form>";
   
    } if (($_SERVER['REQUEST_METHOD']=='POST') AND !isset($error_message)) { //if it is not the first load and if user input has no errors 
        //checking if username and password given match ones in database
        
        $q= "SELECT email, pass from users where email='$email' AND pass=SHA2('$pass',256)";
        $r = mysqli_query ($dbc,$q); 
        if ($r){ 
            if (mysqli_num_rows($r) == 0) { //if not a match print error
                $error_message="Invalid username/password combination.";
                echo "<h3>$error_message</h3>";
            } else { 
                //if a match, print confirmation for user and update session login status
                header('Location: http://' . $_SERVER[ 'HTTP_HOST'].'/admin-1.php');
            }
        }
        else{
            $error_message="Invalid username/password combination.";
                echo "<h3>$error_message</h3>";
            header('Location: http://' . $_SERVER[ 'HTTP_HOST'].'/admin.php');


        }
} 
?>


<?php 
# Display footer section.
include ( 'includes/footer.html' ) ; 

?>