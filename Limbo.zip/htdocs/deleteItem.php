<!DOCTYPE html>
<html>
<!-- Allows the user to see and use hyperlinks -->
<h1>Log out and go back to user view</h1> 
</font>
<font size = "3"> 
<a href=limbo.php>Limbo home</a>
<h1>Admin options</h1>
</font>
<font size = "3">
<a href=admin-2.php>Add found item</a> <a href=admin-3.php>Add lost item</a>
<a href=admin-4.php>Delete item</a> <a href=admin-5.php>Change status</a>
<a href=admin-6.php>Table of Admins</a>
<a href=admin-7.php>Add Admin</a>
<a href=admin-8.php>Delete Admin</a> 
<a href=admin-9.php>Update Admins</a>
<h2>Add Admin</h2> 
<tr>
<table>
<tr> 
<tr>
</tr>
</table>
<?php

require( '../connect_limbo_db.php' ) ;
require( 'includes/helpersLimbo.php' ) ;

if ($_SERVER[ 'REQUEST_METHOD' ]== 'GET') {
    if(isset($_GET['id']))
        delete_item($dbc,$_GET['id']) ;
}

echo "<h1> Entry deleted </h1>" ;

?>

</font>
<font size = "3">
<a href=admin-4.php>Go back</a>
<tr>
<table>
<tr> 
<tr>
</tr>
</table>