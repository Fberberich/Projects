<!DOCTYPE html>
<html>
<!-- Allows the user to see and user hyperlinks -->
<h1>Quick Links</h1> 
</font>
<font size = "3"> 
<a href=lostSomething.php>Lost Something</a> <a href=foundSomething.php> Found Something </a> <a href=admin.php>Admin</a> 
<a href=stuff.php>Stuff</a> <a href=limbo.php>Limbo home</a> <a href=updateLost.php>Update lost item</a>
<a href=updateFound.php>Update found item</a>
<form action="stuff.php" method="POST">
<tr>
<table>
<tr> 
<tr>
</tr>
</table>

<?php
$logo = "images/dog.png" ;
echo "<h1><img border=\"0\" src =" . $logo . " alt=\"Limbo\">" . "Welcome to limbo!  <img border=\"0\" src =" . $logo . " alt=\"Limbo\">","</h1>" ;
echo "<h1>In limbo, you can see if someone has found your lost item.</h1>" ;
echo "<h1>You can also check if someone is looking for an item you've found.</h1>" ;
echo "<h1>Admins can add and delete items from the database.</h1>" ;
echo "<h1>Lastly, you can see more info on each item in the database by pressing on the ID in the 'lost something' or 'found something' pages.</h1>" ;