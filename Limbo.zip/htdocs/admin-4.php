<!DOCTYPE html>
<html>
<!-- Allows the user to see and use hyperlinks -->
<h1>Log out and go back to user view</h1> 
</font>
<font size = "3"> 
<a href=limbo.php>Limbo home</a>
<h1>Admin options</h1>
</font>
<font size = "3">
<a href=admin-2.php>Add found item</a> <a href=admin-3.php>Add lost item</a>
<a href=admin-4.php>Delete item</a> <a href=admin-5.php>Change status</a>
<a href=admin-6.php>Table of Admins</a>
<a href=admin-7.php>Add Admin</a>
<a href=admin-8.php>Delete Admin</a> 
<a href=admin-9.php>Change Password</a>
<a href=admin-10.php>Update Admin</a>
<tr>
<table>
<tr> 
<tr>
</tr>
</table>

<?php

require( '../connect_limbo_db.php' ) ;
require ( 'includes/helpersLimbo.php');

//initialize variables to the user input or if the user input is missing, a blank
if (isset($_POST['id'])){
    $id = $_POST['id'];
}  else {
    $id = "";
}

if (($_SERVER['REQUEST_METHOD']=='POST')){ //variables are saved as blanks and used to populate form, this ensures errors are not shown before the user inputs values

    //error checking for if variables are blank
    if ($id==''){
        $error_message = "<br>Please enter an id";
        echo $error_message;
    } 
}

if (($_SERVER['REQUEST_METHOD']=='GET') OR (isset($error_message))){ //shows form only on first load or if user input has an error
    //begin form
    show_link_delete_records($dbc);
} 