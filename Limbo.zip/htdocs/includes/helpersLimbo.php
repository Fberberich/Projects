<style>
    label{
        float: left;
        clear: left;
        width: 100px;
        text-align: left;
    }
    input{
        float: left;
    }
    .container .btn{
        float: left;
        clear: left;
        width: 100px;
        text-align: left;
    }
    
</style>

<?php
$debug = true;

# Authors: Driver - Frederick Berberich, Navigator - Aaron Bonilla
# Creates a table to show the data from Limbo.sql

# Shows the records in limbo
function show_records($dbc) {

  $query = 'SELECT name, stuff_id, create_date, theStatus FROM theStuff ORDER BY theStatus DESC, create_date DESC' ;

  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;

  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Lost and Found items</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Date</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';

    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
    {   
      echo '<TR>' ;
      echo '<TD>' . $row['stuff_id'] . '</TD>' ;
      echo '<TD>' . $row['name'] . '</TD>' ;
      echo '<TD>' . $row['create_date'] . '</TD>' ;
      echo '<TD>' . $row['theStatus'] . '</TD>' ;
      echo '</TR>' ;
    }

    # End the table
    echo '</TABLE>';

    # Free up the results in memory
    mysqli_free_result( $results ) ;
  }
}

function show_records_changeable_found($dbc) {

  $query = 'SELECT * FROM theStuff WHERE theStatus = "found" ORDER BY create_date DESC' ;

  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;

  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Changeable items</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Location</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Description</TH>';
    echo '<TH>Create Date</TH>';
    echo '<TH>Update Date</TH>';
    echo '<TH>Room</TH>';
    echo '<TH>Finder</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';

    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
    {   
      # Determines what building each location_id refers to
    if($row['location_id'] == 1){
      $location = "Hancock";
    }   
    else if($row['location_id'] == 2){
      $location = "Dyson";
    }
    else if($row['location_id'] == 3){
      $location = "McCann Center";
    }
    else if($row['location_id'] == 4){
      $location = "Lowell Thomas";
    }
    else if($row['location_id'] == 5){
      $location = "Fontain Hall";
    }
    else if($row['location_id'] == 6){
      $location = "Allied Health";
    }
    else if($row['location_id'] == 7){
      $location = "Steel Plant";
    }
    else if($row['location_id'] == 8){
      $location = "Murray Student Center";
    }


      echo '<TR>' ;
      echo '<TD>' . $row['stuff_id'] . '</TD>' ;
      echo '<TD>' . $location . '</TD>' ;
      echo '<TD>' . $row['name'] . '</TD>' ;
      echo '<TD>' . $row['theDescription'] . '</TD>' ;
      echo '<TD>' . $row['create_date'] . '</TD>' ;
      echo '<TD>' . $row['update_date'] . '</TD>' ;
      echo '<TD>' . $row['room'] . '</TD>' ;
      echo '<TD>' . $row['finder'] . '</TD>' ;
      echo '<TD>' . $row['theStatus'] . '</TD>' ;
      echo '</TR>' ;
    }

    # End the table
    echo '</TABLE>';

    # Free up the results in memory
    mysqli_free_result( $results ) ;
  }
}

function show_records_changeable_lost($dbc) {

  $query = 'SELECT * FROM theStuff WHERE theStatus = "lost" ORDER BY create_date DESC' ;

  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;

  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Changeable items</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Location</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Description</TH>';
    echo '<TH>Create Date</TH>';
    echo '<TH>Update Date</TH>';
    echo '<TH>Owner</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';

    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
    {   
      # Determines what building each location_id refers to
    if($row['location_id'] == 1){
      $location = "Hancock";
    }   
    else if($row['location_id'] == 2){
      $location = "Dyson";
    }
    else if($row['location_id'] == 3){
      $location = "McCann Center";
    }
    else if($row['location_id'] == 4){
      $location = "Lowell Thomas";
    }
    else if($row['location_id'] == 5){
      $location = "Fontain Hall";
    }
    else if($row['location_id'] == 6){
      $location = "Allied Health";
    }
    else if($row['location_id'] == 7){
      $location = "Steel Plant";
    }
    else if($row['location_id'] == 8){
      $location = "Murray Student Center";
    }


      echo '<TR>' ;
      echo '<TD>' . $row['stuff_id'] . '</TD>' ;
      echo '<TD>' . $location . '</TD>' ;
      echo '<TD>' . $row['name'] . '</TD>' ;
      echo '<TD>' . $row['theDescription'] . '</TD>' ;
      echo '<TD>' . $row['create_date'] . '</TD>' ;
      echo '<TD>' . $row['update_date'] . '</TD>' ;
      echo '<TD>' . $row['theOwner'] . '</TD>' ;
      echo '<TD>' . $row['theStatus'] . '</TD>' ;
      echo '</TR>' ;
    }

    # End the table
    echo '</TABLE>';

    # Free up the results in memory
    mysqli_free_result( $results ) ;
  }
}

function show_records_changeable($dbc) {

  $query = 'SELECT name, stuff_id, create_date, theStatus FROM theStuff ORDER BY theStatus DESC, create_date DESC' ;

  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;

  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Changeable items</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Date</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';

    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
    {   
      echo '<TR>' ;
      echo '<TD>' . $row['stuff_id'] . '</TD>' ;
      echo '<TD>' . $row['name'] . '</TD>' ;
      echo '<TD>' . $row['create_date'] . '</TD>' ;
      echo '<TD>' . $row['theStatus'] . '</TD>' ;
      echo '</TR>' ;
    }

    # End the table
    echo '</TABLE>';

    # Free up the results in memory
    mysqli_free_result( $results ) ;
  }
}

# Shows the records in limbo
function show_records_lost($dbc) {

  $query = 'SELECT name, stuff_id, create_date, theStatus FROM theStuff WHERE theStatus = "lost" ORDER BY create_date DESC';
  
  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;
  
  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Lost items</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Date</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';
  
    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
    {   
      echo '<TR>' ;
      echo '<TD>' . $row['stuff_id'] . '</TD>' ;
      echo '<TD>' . $row['name'] . '</TD>' ;
      echo '<TD>' . $row['create_date'] . '</TD>' ;
      echo '<TD>' . $row['theStatus'] . '</TD>' ;
      echo '</TR>' ;

    }
  
    # End the table
    echo '</TABLE>';
  
    # Free up the results in memory
    mysqli_free_result( $results ) ;
  }
}

# Shows the records in limbo
function show_records_found($dbc) {

  # query to select information for items with the 'found' status
  $query = 'SELECT name, stuff_id, create_date, theStatus FROM theStuff WHERE theStatus = "found" ORDER BY create_date DESC';
    
  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;
    
  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Found items</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Date</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';
    
    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
    {   
      echo '<TR>' ;
      echo '<TD>' . $row['stuff_id'] . '</TD>' ;
      echo '<TD>' . $row['name'] . '</TD>' ;
      echo '<TD>' . $row['create_date'] . '</TD>' ;
      echo '<TD>' . $row['theStatus'] . '</TD>' ;
      echo '</TR>' ;
    }
    
    # End the table
    echo '</TABLE>';
    
    # Free up the results in memory
    mysqli_free_result( $results ) ;
  }
}

# Inserts a lost item into the stuff table
function insert_record_lost($dbc, $location, $name, $description, $owner) {
  # Determines what building each location_id refers to
  if($location == "Hancock"){
    $location_id = 1;
  }    
  else if($location == "Dyson"){
    $location_id = 2;
  }
  else if($location == "McCann Center"){
    $location_id = 3;
  }
  else if($location == "Lowell Thomas"){
    $location_id = 4;
  }
  else if($location == "Fontain Hall"){
    $location_id = 5;
  }
  else if($location == "Allied Health"){
    $location_id = 6;
  }
  else if($location == "Steel Plant"){
    $location_id = 7;
  }
  else if($location == "Murray Student Center"){
    $location_id = 8;
  }

  $query = "INSERT INTO theStuff(location_id, name, theDescription, create_date, update_date, theOwner, theStatus)
   VALUES ('$location_id' , '$name' , '$description' ,
   NOW(), NOW(), '$owner', 'lost' )" ;
  show_query($query);
  
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;

  return $results ; 
}

  # Inserts a found item into the stuff table
function insert_record_found($dbc, $location, $name, $description, $room, $finder) {
  # Determines what building each location_id refers to

  $location_id = 0;
  if($location == "Hancock"){
    $location_id = 1;
  }    
  else if($location == "Dyson"){
    $location_id = 2;
  }
  else if($location == "McCann Center"){
    $location_id = 3;
  }
  else if($location == "Lowell Thomas"){
    $location_id = 4;
  }
  else if($location == "Fontain Hall"){
    $location_id = 5;
  }
  else if($location == "Allied Health"){
    $location_id = 6;
  }
  else if($location == "Steel Plant"){
    $location_id = 7;
  }
  else if($location == "Murray Student Center"){
    $location_id = 8;
  }
  
  $query = "INSERT INTO theStuff(location_id, name, theDescription, create_date, update_date, room, finder, theStatus)
  VALUES ('$location_id', '$name' ,  '$description'  ,
   NOW()  ,  NOW()  ,  '$room' , '$finder'   ,  'found'  )" ;
  show_query($query);


  $results = mysqli_query($dbc,$query) ;

  return $results ;
}

# deletes an item from the database
function delete_item($dbc, $id){
  $query ="DELETE FROM theStuff WHERE stuff_id = $id" ;

  #show_query($query);

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;

  return $results ;
}

function update_record_adminPassword($dbc, $newpass, $id){
  
  $query ="UPDATE users SET pass = SHA2('$newpass',256) WHERE theUser_id = $id";
  

  $results= mysqli_query($dbc , $query);
  check_results($results) ;

  return($results);
}

function update_record_found($dbc,$id,$location,$newN,$newD,$newR,$newF){

  $location_id = 0;
  if($location == "Hancock"){
    $location_id = 1;
  }    
  else if($location == "Dyson"){
    $location_id = 2;
  }
  else if($location == "McCann Center"){
    $location_id = 3;
  }
  else if($location == "Lowell Thomas"){
    $location_id = 4;
  }
  else if($location == "Fontain Hall"){
    $location_id = 5;
  }
  else if($location == "Allied Health"){
    $location_id = 6;
  }
  else if($location == "Steel Plant"){
    $location_id = 7;
  }
  else if($location == "Murray Student Center"){
    $location_id = 8;
  }
  
  
  $query ="UPDATE theStuff SET location_id = '$location_id', name = '$newN', theDescription = '$newD',
  room = '$newR', finder = '$newF', update_date = NOW() WHERE stuff_id = $id";
  

  $results= mysqli_query($dbc , $query);
  check_results($results) ;

  return($results);
}

function update_record_lost($dbc,$id,$location,$newN,$newD,$newO){

  $location_id = 0;
  if($location == "Hancock"){
    $location_id = 1;
  }    
  else if($location == "Dyson"){
    $location_id = 2;
  }
  else if($location == "McCann Center"){
    $location_id = 3;
  }
  else if($location == "Lowell Thomas"){
    $location_id = 4;
  }
  else if($location == "Fontain Hall"){
    $location_id = 5;
  }
  else if($location == "Allied Health"){
    $location_id = 6;
  }
  else if($location == "Steel Plant"){
    $location_id = 7;
  }
  else if($location == "Murray Student Center"){
    $location_id = 8;
  }
  
  
  $query ="UPDATE theStuff SET location_id = '$location_id', name = '$newN', theDescription = '$newD',
  theOwner = '$newO', update_date = NOW() WHERE stuff_id = $id";
  

  $results= mysqli_query($dbc , $query);
  check_results($results) ;

  return($results);
}

function update_record_adminInfo($dbc, $newF, $newL, $newE, $id){
  
  $query ="UPDATE users SET first_name = '$newF', last_name = '$newL', email = '$newE' WHERE theUser_id = $id";
  

  $results= mysqli_query($dbc , $query);
  check_results($results) ;

  return($results);
}

# deletes an admin from the database
function delete_admin($dbc, $id){
  $query ="DELETE FROM users WHERE theUser_id = $id" ;

  #show_query($query);

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;

  return $results ;
}

function change_item($dbc, $id, $newStatus){
  $query ="UPDATE theStuff SET theStatus = '$newStatus' WHERE stuff_id =$id";

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;

  return $results ;
}

function show_records_admin($dbc) {

  # Execute the query
  $query = 'SELECT theUser_id, first_name, last_name, email, pass, reg_date FROM users';
  $results = mysqli_query( $dbc , $query ) ;
  
  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Admins</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>First Name</TH>';
    echo '<TH>Last name</TH>';
    echo '<TH>Email</TH>';
    echo '<TH>Password</TH>';
    echo '<TH>Registration date</TH>';
    echo '</TR>';

    while($row = mysqli_fetch_array($results,MYSQLI_ASSOC))
    {
      echo '<tr>';
      echo '<td>' . $row['theUser_id'] . '</td>' ; 
      echo '<td>' . $row['first_name'] . '</td>' ; 
      echo '<td>' . $row['last_name'] . '</td>' ; 
      echo '<td>' . $row['email'] . '</td>' ; 
      echo '<td>' . $row['pass'] . '</td>' ; 
      echo '<td>' . $row['reg_date'] . '</td>'; 
      echo '</tr>';
    }

    echo '</table>';
  
  
    # Free up the results in memory
    mysqli_free_result( $results ) ;
  }
}

function insert_record_admins($dbc, $first_name, $last_name, $email, $pass) {

  $query = "INSERT INTO users(first_name, last_name, email , pass, reg_date)
   VALUES ('$first_name' , '$last_name' , '$email' ,
   SHA2('$pass',256),NOW())" ;
  show_query($query);
  
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;

  return $results ; 
}

function delete_record_admins($dbc, $id) {

  $query ="DELETE FROM users WHERE theUser_id = $id" ;

  #show_query($query);

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;

  return $results ;
}


# Shows the query as a debugging aid
function show_query($query) {
  global $debug;

  if($debug)
    echo "<p>Query = $query</p>" ;
}

# Checks the query results as a debugging aid
function check_results($results) {
  global $dbc;

  if($results != true)
    echo '<p>SQL ERROR = ' . mysqli_error( $dbc ) . '</p>'  ;
}

function show_record_lost($dbc, $id) {

  $query = 'SELECT * FROM theStuff WHERE stuff_id = ' . $id ;

  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;

  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Lost Item Info</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Location</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Description</TH>';
    echo '<TH>Create Date</TH>';
    echo '<TH>Update Date</TH>';
    echo '<TH>Owner</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';


  # For each row result, generate a table row
  if ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    # Determines what building each location_id refers to
    if($row['location_id'] == 1){
      $location = "Hancock";
    }   
    else if($row['location_id'] == 2){
      $location = "Dyson";
    }
    else if($row['location_id'] == 3){
      $location = "McCann Center";
    }
    else if($row['location_id'] == 4){
      $location = "Lowell Thomas";
    }
    else if($row['location_id'] == 5){
      $location = "Fontain Hall";
    }
    else if($row['location_id'] == 6){
      $location = "Allied Health";
    }
    else if($row['location_id'] == 7){
      $location = "Steel Plant";
    }
    else if($row['location_id'] == 8){
      $location = "Murray Student Center";
    }  
    echo '<TR>' ;
    echo '<TD>' . $row['stuff_id'] . '</TD>' ;
    echo '<TD>' . $location . '</TD>' ;
    echo '<TD>' . $row['name'] . '</TD>' ;
    echo '<TD>' . $row['theDescription'] . '</TD>' ;
    echo '<TD>' . $row['create_date'] . '</TD>' ;
    echo '<TD>' . $row['update_date'] . '</TD>' ;
    echo '<TD>' . $row['theOwner'] . '</TD>' ;
    echo '<TD>' . $row['theStatus'] . '</TD>' ;
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
  }
}

function show_record_found($dbc, $id) {

  $query = 'SELECT * FROM theStuff WHERE stuff_id = ' . $id ; 

  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;
  
  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Found Item Info</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Location</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Description</TH>';
    echo '<TH>Create Date</TH>';
    echo '<TH>Update Date</TH>';
    echo '<TH>Room</TH>';
    echo '<TH>Finder</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';

  
  # For each row result, generate a table row
  if ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    # Determines what building each location_id refers to
    if($row['location_id'] == 1){
      $location = "Hancock";
    }   
    else if($row['location_id'] == 2){
      $location = "Dyson";
    }
    else if($row['location_id'] == 3){
      $location = "McCann Center";
    }
    else if($row['location_id'] == 4){
      $location = "Lowell Thomas";
    }
    else if($row['location_id'] == 5){
      $location = "Fontain Hall";
    }
    else if($row['location_id'] == 6){
      $location = "Allied Health";
    }
    else if($row['location_id'] == 7){
      $location = "Steel Plant";
    }
    else if($row['location_id'] == 8){
      $location = "Murray Student Center";
    }  
    echo '<TR>' ;
    echo '<TD>' . $row['stuff_id'] . '</TD>' ;
    echo '<TD>' . $location . '</TD>' ;
    echo '<TD>' . $row['name'] . '</TD>' ;
    echo '<TD>' . $row['theDescription'] . '</TD>' ;
    echo '<TD>' . $row['create_date'] . '</TD>' ;
    echo '<TD>' . $row['update_date'] . '</TD>' ;
    echo '<TD>' . $row['room'] . '</TD>' ;
    echo '<TD>' . $row['finder'] . '</TD>' ;
    echo '<TD>' . $row['theStatus'] . '</TD>' ;
    echo '</TR>' ;
  }
  
  # End the table
  echo '</TABLE>';
  
  # Free up the results in memory
  mysqli_free_result( $results ) ;
  }
}

function show_link_found_records($dbc) {
 
  $query = 'SELECT stuff_id , name, create_date, theStatus FROM theStuff WHERE theStatus = "found" ORDER BY create_date DESC';
  
  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;
  
  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Found items</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Date</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';

    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) ) {
      $alink = '<A HREF=lostItem.php?id=' . $row['stuff_id'] . '>' . $row['stuff_id'] . '</A>' ;
      echo '<TR>' ;
      echo '<TD ALIGN=right>' . $alink . '</TD>' ;
      echo '<TD>' . $row['name'] . '</TD>' ;
      echo '<TD>' . $row['create_date'] . '</TD>' ;
      echo '<TD>' . $row['theStatus'] . '</TD>' ;
      echo '</TR>' ;
    }

  }
  
    # End the table
    echo '</TABLE>';
  
    # Free up the results in memory
    mysqli_free_result( $results ) ;
}

function show_link_delete_records($dbc) {
 
  $query = 'SELECT stuff_id , name, create_date, theStatus FROM theStuff ORDER BY create_date DESC';
  
  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;
  
  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Deletable Items</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Date</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';

    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) ) {
      $alink = '<A HREF=deleteItem.php?id=' . $row['stuff_id'] . '>' . $row['stuff_id'] . '</A>' ;
      echo '<TR>' ;
      echo '<TD ALIGN=right>' . $alink . '</TD>' ;
      echo '<TD>' . $row['name'] . '</TD>' ;
      echo '<TD>' . $row['create_date'] . '</TD>' ;
      echo '<TD>' . $row['theStatus'] . '</TD>' ;
      echo '</TR>' ;
    }

  }
  
    # End the table
    echo '</TABLE>';
  
    # Free up the results in memory
    mysqli_free_result( $results ) ;
}

function show_link_delete_admins($dbc) {
 
  $query = 'SELECT theUser_id , first_name, last_name, pass FROM users ORDER BY theUser_id DESC';
  
  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;
  
  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Deletable Admins</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>First name</TH>';
    echo '<TH>Last name</TH>';
    echo '<TH>Password</TH>';
    echo '</TR>';

    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) ) {
      $alink = '<A HREF=deleteAdmin.php?id=' . $row['theUser_id'] . '>' . $row['theUser_id'] . '</A>' ;
      echo '<TR>' ;
      echo '<TD ALIGN=right>' . $alink . '</TD>' ;
      echo '<TD>' . $row['first_name'] . '</TD>' ;
      echo '<TD>' . $row['last_name'] . '</TD>' ;
      echo '<TD>' . $row['pass'] . '</TD>' ;
      echo '</TR>' ;
    }

  }
  
    # End the table
    echo '</TABLE>';
  
    # Free up the results in memory
    mysqli_free_result( $results ) ;
}

function show_link_change_records($dbc) {
 
  $query = 'SELECT stuff_id , name, create_date, theStatus FROM theStuff ORDER BY create_date DESC';
  
  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;
  
  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Changeable Items</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Date</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';

    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) ) {
      $alink = '<A HREF=changeItem.php?id=' . $row['stuff_id'] . '>' . $row['stuff_id'] . '</A>' ;
      echo '<TR>' ;
      echo '<TD ALIGN=right>' . $alink . '</TD>' ;
      echo '<TD>' . $row['name'] . '</TD>' ;
      echo '<TD>' . $row['create_date'] . '</TD>' ;
      echo '<TD>' . $row['theStatus'] . '</TD>' ;
      echo '</TR>' ;
    }

  }
  
    # End the table
    echo '</TABLE>';
  
    # Free up the results in memory
    mysqli_free_result( $results ) ;
}

function show_link_lost_records($dbc) {
 
   $query = 'SELECT stuff_id, name, create_date, theStatus FROM theStuff WHERE theStatus = "lost" ORDER BY create_date DESC';
  
  # Execute the query
  $results = mysqli_query( $dbc , $query ) ;
  
  # Show results
  if( $results )
  {
    # But...wait until we know the query succeeded before
    # starting the table.
    echo '<H1>Lost items</H1>' ;
    echo '<TABLE border="1">';
    echo '<TR>';
    echo '<TH>ID</TH>';
    echo '<TH>Name</TH>';
    echo '<TH>Date</TH>';
    echo '<TH>Status</TH>';
    echo '</TR>';

    # For each row result, generate a table row
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) ) {
      $alink = '<A HREF=foundItem.php?id=' . $row['stuff_id'] . '>' . $row['stuff_id'] . '</A>' ;
      echo '<TR>' ;
      echo '<TD ALIGN=right>' . $alink . '</TD>' ;
      echo '<TD>' . $row['name'] . '</TD>' ;
      echo '<TD>' . $row['create_date'] . '</TD>' ;
      echo '<TD>' . $row['theStatus'] . '</TD>' ;
      echo '</TR>' ;
    }

  }
  
    # End the table
    echo '</TABLE>';
  
    # Free up the results in memory
    mysqli_free_result( $results ) ;
}
?>