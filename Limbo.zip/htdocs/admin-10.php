<!DOCTYPE html>
<html>
<style>
    label{
        float: left;
        clear: left;
        width: 100px;
        text-align: left;
    }
    input{
        float: left;
    }
    .container .btn{
        float: left;
        clear: left;
        width: 100px;
        text-align: left;
    }
    
</style>        
<!-- Allows the user to see and use hyperlinks -->
<h1>Log out and go back to user view</h1> 
</font>
<font size = "3"> 
<a href=limbo.php>Limbo home</a>
<h1>Admin options</h1>
</font>
<font size = "3">
<a href=admin-2.php>Add found item</a> <a href=admin-3.php>Add lost item</a>
<a href=admin-4.php>Delete item</a> <a href=admin-5.php>Change status</a>
<a href=admin-6.php>Table of Admins</a>
<a href=admin-7.php>Add Admin</a>
<a href=admin-8.php>Delete Admin</a> 
<a href=admin-9.php>Change Password</a>
<a href=admin-10.php>Update Admin</a>
<tr>
<table>
<tr> 
<tr>
</tr>
</table>

<?php

require( '../connect_limbo_db.php' ) ;
require ( 'includes/helpersLimbo.php');

if (isset($_POST['id'])){
    $id = $_POST['id'];
} else {
    $id = "";
}
if (isset($_POST['newF'])){
    $newF = $_POST['newF'];
} else {
    $newF = "";
}
if (isset($_POST['newL'])){
    $newL = $_POST['newL'];
} else {
    $newL = "";
}
if (isset($_POST['newE'])){
    $newE = $_POST['newE'];
} else {
    $newE = "";
}

if (($_SERVER['REQUEST_METHOD']=='POST')){ //variables are saved as blanks and used to populate form, this ensures errors are not shown before the user inputs values
    
    //error checking for if variables are blank
        if ($newF=='') {
            $error_message = "<br>Please enter a first name";
            echo $error_message;
        } 
        if ($newL=='') {
            $error_message = "<br>Please enter a last name";
            echo $error_message;
        } 
        if ($newE=='') {
            $error_message = "<br>Please enter a email";
            echo $error_message;
        } 
}

show_records_admin($dbc);

$query = "SELECT theUser_id FROM users";
$results = mysqli_query( $dbc , $query ) ;

//begin form
echo "<form action='' method='POST'>";
?>

<div>
    <label>Admin ID:</label><select name='id' id='$id'>
    <?php
    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) ){
        echo "<option value='" . $row['theUser_id'] . "'>" .$row['theUser_id']."</option>";
    }  
    ?>
    </select>  
</div>

<div>
<label>New first name:</label><input name='newF' id='$newF'>
<label>New last name:</label><input name='newL' id='$newL'>
<label>New email:</label><input name='newE' id='$newE'>
    <label><input type='submit' class='btn' value='Submit'>
</div>

<?php

//end form
echo "</form>";


if ($_SERVER['REQUEST_METHOD']=='POST' and !isset($error_message)){
    if(update_record_adminInfo($dbc,$newF,$newL,$newE,$id)){
        echo "<h1>Entry successfully changed, refresh to see changes</h1>";
    }
}