<!DOCTYPE html>
<html>
<!-- Allows the user to see and use hyperlinks -->
<h1>Log out and go back to user view</h1> 
</font>
<font size = "3"> 
<a href=limbo.php>Limbo home</a>
<h1>Admin options</h1>
</font>
<font size = "3">
<a href=admin-2.php>Add found item</a> <a href=admin-3.php>Add lost item</a>
<a href=admin-4.php>Delete item</a> <a href=admin-5.php>Change status</a>
<a href=admin-6.php>Table of Admins</a>
<a href=admin-7.php>Add Admin</a>
<a href=admin-8.php>Delete Admin</a> 
<a href=admin-9.php>Change Password</a>
<a href=admin-10.php>Update Admin</a>
<h2>Add Admin</h2> 
<tr>
<table>
<tr> 
<tr>
</tr>
</table>

<?php

require( '../connect_limbo_db.php' ) ;
require ( 'includes/helpersLimbo.php');

//initialize variables to the user input or if the user input is missing, a blank
if (isset($_POST['first_name'])){
    $first_name = $_POST['first_name'];
} else {
    $first_name = "";
}
if (isset($_POST['last_name'])){
    $last_name = $_POST['last_name'];
} else {
    $last_name = "";
}
if (isset($_POST['email'])){
    $email = $_POST['email'];
} else {
    $email = "";
}
if (isset($_POST['pass'])){
    $pass = $_POST['pass'];
} else {
    $pass = "";
}


if (($_SERVER['REQUEST_METHOD']=='POST')){ //variables are saved as blanks and used to populate form, this ensures errors are not shown before the user inputs values

//error checking for if variables are blank
    if ($first_name==''){
        $first_name = "<br>Please enter a location";
        echo $error_message;
    } 
    if ($last_name=='') {
        $error_message = "<br>Please enter a name";
        echo $error_message;
    }
    if ($email=='') {
        $error_message = "<br>Please enter a description";
        echo $error_message;
    }
    if ($pass=='') {
        $error_message = "<br>Please enter a owner";
        echo $error_message;
    } 
}

if (($_SERVER['REQUEST_METHOD']=='GET') OR (isset($error_message))){ //shows form only on first load or if user input has an error
    //begin form
    echo "<form action='' method='POST'>";
    ?>
     <div>
        <label>First Name:</label><input value = '' type='text' name='first_name'>
        <label>Last Name:</label> <input value = '' type='text' name='last_name'>
        <label>Email:</label> <input value = '' type='text' name='email'>
        <label>Password:</label> <input value = '' type='text' name='pass'>
        <label><input type='submit' class='btn' value='Submit'>
    </div>

    <?php
    //end form
    echo "</form>";

} if (($_SERVER['REQUEST_METHOD']=='POST') AND !isset($error_message)) { //if it is not the first load and if user input has no errors 
    //checks if the new entry was added and notifies the user
    if(insert_record_admins($dbc, $first_name, $last_name, $email, $pass)){
        echo "<h1>New admin successfully added</h1>";
    }
} 

?>