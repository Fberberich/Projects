<?php

echo "<h1>Successfully logged in</h1>" ;

?>

<!DOCTYPE html>
<html>
<!-- Allows the user to see and use hyperlinks -->
<h1>Log out and go back to user view</h1> 
</font>
<font size = "3"> 
<a href=limbo.php>Limbo home</a>
<h1>Admin options</h1>
</font>
<font size = "3">
<a href=admin-2.php>Add found item</a> <a href=admin-3.php>Add lost item</a>
<a href=admin-4.php>Delete item</a> <a href=admin-5.php>Change status</a>
<a href=admin-6.php>Table of Admins</a>
<a href=admin-7.php>Add Admin</a>
<a href=admin-8.php>Delete Admin</a> 
<a href=admin-9.php>Change Password</a> 
<a href=admin-10.php>Update Admin</a>
<tr>
<table>
<tr> 
<tr>
</tr>
</table>


<?php
require( '../connect_limbo_db.php' ) ;
require( 'includes/helpersLimbo.php' ) ;
show_records_admin($dbc);


?>